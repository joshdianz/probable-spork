<header>
    <div id="upperHeader">
        <ul>
            <li id="logo">E-commerce<br><span>Inventory App</span></li>
            <li>Email: <a href="mailto:richardg@mastergradeit.co.za">richardg@mastergradeit.co.za</a></li>
            <li>Tel: <a href="tel:+27214193213">+27 21 419 3213</a></li>
        </ul>
    </div>
    <nav>
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
            <li><a href="login.php">Login</a></li>
        </ul>
    </nav>
</header>
