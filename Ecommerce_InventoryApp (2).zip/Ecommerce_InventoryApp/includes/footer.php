<footer>
    <div id="newsletter">
        <form action="" method="POST">
            <p>Subscribe to our Newsletter</p>
            <input type="email" class="txt" name="subEmail" placeholder="Email: example@gmail.com" required>
            <input type="submit" value="Subscribe" id="btnSubscribe">
        </form>
    </div>
    <div id="contacts">
        <div>
            <h3>About</h3><br>
            <p>Video provides a powerful way to help you prove your point. When you click Online Video, you can paste in the embed code for the video you want to add.</p>
            <ul>
                <li><a href="#">facebook</a></li>
                <li><a href="#">youtube</a></li>
                <li><a href="#">instagram</a></li>
                <li><a href="#">linkedIn</a></li>
            </ul>
        </div>
        <div>
            <H3>Page</H3><br>
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
        </div>
        <div>
            <h3>Contact</h3><br>
            <form action="" method="POST">
                <input type="email" class="txt" name="ConEmail" placeholder="Email: example@gmail.com" required><br> 
                <textarea id="txtArea" name="message" placeholder="Please leave a message"></textarea><br>
                <input type="submit" value="Send" id="btncon">
            </form>
        </div>
    </div>
    <div id="copyrights">
        &copy; MGIT 2021, all rights reserved.
    </div>
</footer>

