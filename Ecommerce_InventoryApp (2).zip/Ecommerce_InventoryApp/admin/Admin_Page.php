<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
    include '../logic.php';
    $obj = new AppLogic();
    
    if(isset($_POST['btnSearch'])){
        $search = filter_input(INPUT_POST,'email');

        $obj->serverCon();
        
        $searchQuery = "select * from userinfo where Email = '".$search."'";
        $searchResults = mysqli_query($link, $searchQuery);
        $searchFetch = mysqli_fetch_array($searchResults);
        
        $fname = $searchFetch['Firstname'];
        $lname = $searchFetch['Lastname']; 
        $mail = $searchFetch['Email'];
    }
    
    //Add User
    if(isset($_POST['btnAddUser'])){
        $fname = filter_input(INPUT_POST, 'fname');
        $lname = filter_input(INPUT_POST, 'lname');
        $email = filter_input(INPUT_POST, 'email');
        $pword = filter_input(INPUT_POST, 'pword');
        $phone = filter_input(INPUT_POST, 'phone');
        
        $obj->AddUser($fname, $lname, $email, $pword, $phone);
    }
    
    //delete user
    if(isset($_POST['btnDelete'])){
        $email = filter_input(INPUT_POST, 'email');
        
        $obj->DeleteUser($email);
    }
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    <link rel="stylesheet" href="../css/style.css">
    </head>
    <body>
        <?php
        // include the header here
        include '../admin/includes/adminHeader.php';
        ?>
        <div id="main">
            <div id="formDiv">
                <form action="" method="POST">
                    <h3>Search for a record using Email</h3>
                    <input type="email" name="email" placeholder="Email: examaple@gmail.com" required>
                    <input type="submit" name="btnSearch" value="Search"><br>
                </form>
                <form action="" method="POST">
                    <h3>User Form</h3>
                   <input type="text" name="fname" placeholder="Firstname" value="<?php if(isset($_POST['btnSearch'])){echo $fname;} ?>" required><br>
                   <input type="text" name="lname" placeholder="Lastname" value="<?php if(isset($_POST['btnSearch'])){ echo $lname;} ?>" required><br>
                   <input type="email" name="email" placeholder="Email: examaple@gmail.com" value="<?php if(isset($_POST['btnSearch'])){ echo $mail;} ?>"required><br>
                   <input type="password" name="pword" placeholder="Password" required><br>
                   <input type="password" name="conPass" placeholder="Confirm Password" required><br>
                   <input type="text" name="phone" placeholder="Phone" required><br>
                   <input type="file" name="file"><br>
                   <input type="submit" name="btnAddUser" value="Add User">&nbsp;&nbsp;
                   <input type="submit" name="btnDelete" value="Delete User">&nbsp;&nbsp;
                   <input type="submit" name="btnUpdate" value="Update User"><br> 
                </form>
            </div>
        </div>
        <?php
        // include the footer here
        include '../includes/footer.php';
        ?>
    </body>
</html>
