<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
    include '../logic.php';
    $obj = new product();
    if(isset($_POST['btnAddProd'])){
        
        $prodName = filter_input(INPUT_POST, "prodName");
        $cost = filter_input(INPUT_POST, "cost");
        $qty = filter_input(INPUT_POST, "qty");
        $desc = filter_input(INPUT_POST, "desc");
        $reorder = 20;
        $fileName = $_FILES['file']['name'];
        $fileTmp = $_FILES['file']['tmp_name'];
        
        //create a permanent storage location
        
        $obj->AddProduct($prodName, $cost, $qty, $desc, $reorder, $fileName, $fileTmp);
    }
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    <link rel="stylesheet" href="../css/style.css">
    </head>
    <body>
        <?php
        // include the header here
        include '../admin/includes/adminHeader.php';
        ?>
        <div id="main">
            <div id="formDiv">
                <form action="" method="POST">
                    <h3>Search for a record using Email</h3>
                    <input type="email" name="email" placeholder="Email: examaple@gmail.com" required>
                    <input type="submit" name="btnSearch" value="Search"><br>
                </form>
                <form action="" method="POST" enctype="multipart/form-data">
                    <h3>Product Form</h3>
                   <input type="text" name="prodName" placeholder="Product Name" value="<?php if(isset($_POST['btnSearch'])){echo $fname;} ?>" required><br>
                   <input type="text" name="cost" placeholder="Cost" value="<?php if(isset($_POST['btnSearch'])){ echo $lname;} ?>" required><br>
                   <input type="number" name="qty" placeholder="Quantity" value="<?php if(isset($_POST['btnSearch'])){ echo $mail;} ?>"required><br>
                   <input type="text" name="desc" placeholder="Description" required><br>
                   <input type="number" name="reorder" placeholder="Re-order level" required readonly><br>
                   <input type="file" name="file"><br>
                   <input type="submit" name="btnAddProd" value="Add Product">&nbsp;&nbsp;
                   <input type="submit" name="btnDelete" value="Delete Product">&nbsp;&nbsp;
                   <input type="submit" name="btnUpdate" value="Update Product"><br> 
                </form>
            </div>
        </div>
        <?php
        // include the footer here
        include '../includes/footer.php';
        ?>
    </body>
</html>
