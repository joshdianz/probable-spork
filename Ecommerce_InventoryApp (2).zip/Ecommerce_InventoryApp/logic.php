<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class AppLogic{ //blue print of your program
    function serverCon(){
        global $link;
        $lhost = "localhost";
        $user = "root";
        $pass = "";
        $dbase = "ecommerce_invdb";
        
        //Declare a connection string
        $link = mysqli_connect($lhost, $user, $pass) or die("Failed to connect to server");
        
        //Select our dbase
        mysqli_select_db($link, $dbase) or die("Dbase not found");   
    }
    function AddUser($fname, $lname, $email, $pword, $phone){
        $obj = new AppLogic();
        $obj->serverCon();
        global $link;
        
        //Declaring a query statement to insert a record 
        $queryAddUser = "insert into userinfo(Email, Firstname, Lastname, Password, Phone) values('".$email."', '".$fname."', '".$lname."', '".$pword."', '".$phone."')";
        
        //Execute our query
        mysqli_query($link, $queryAddUser);
    }
    
    function DeleteUser($email){
        $obj = new AppLogic();
        $obj->serverCon();
        global $link;
        
        $queryDelete = "delete from userinfo where Email = '".$email."'";
        mysqli_query($link, $queryDelete);
        ?>
            <script>
                alert("Record has been successfully deleted");
            </script>
        <?php
    }
}

class product{
    function AddProduct($prodName, $cost, $qty, $desc, $reorder, $fileName, $fileTmp){
        $obj = new AppLogic();
        $obj->serverCon();
        global $link;
        
        $permLocation = "../admin/assets/Images/".$fileName;
        move_uploaded_file($fileTmp, $permLocation);
        
        $addProdQuery = "insert into products(ProductName, Cost, Quantity, Description, Re_Order_level, Image) values('".$prodName."','".$cost."','".$qty."','".$desc."','".$reorder."','".$fileName."')";
        mysqli_query($link, $addProdQuery);   
    }
    
    function DelProduct(){
        
    }
    
    function UpdateProduct(){
        
    }
}

