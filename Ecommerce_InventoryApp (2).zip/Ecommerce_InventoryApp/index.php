<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="css/style.css">
        <style>
            #main{
                padding: 0px 100px;
            }
            #items{
                display: grid;
                grid-template-columns: repeat(3, 1fr);
                grid-gap: 60px;
            }
            #items img{
                width: 100%;
            }
            .innerDiv{
                border-style: solid;
                border-color: grey;
                border-width: 1px;
                padding: 30px;
                text-align: center;
                box-shadow: grey 5px 10px 15px;
            }
        </style>
    </head>
    <body>
        <?php
        // include the header here
        include 'includes/header.php';
        ?>
        <div id="main">
            <?php
                    include 'logic.php';
                    $obj = new AppLogic();
                    $obj->serverCon();
                    
                    $query = "select * from products";
                    $results = mysqli_query($link, $query);
                    echo '<div id="items">';
                    while ($row = mysqli_fetch_array($results)) {
                        echo '<div class="innerDiv">';
//                            echo "<img src=assets/".$row['image'].">";
                            echo "<img src=admin/assets/Images/".$row['Image'].">";
                            echo "<h3>".$row['ProductName']."</h3><br>"; 
                            echo "<h2>".$row['Cost']."</h2><br>";
                            echo "<p>".$row['Description']."</p><br>";
                            echo "<button type='button' name='btnCart'>Add To Cart</button>";
                        echo '</div>';
                    }
                    echo '</div>';
                    
            ?>
        </div>
        <?php
        // include the footer here
        include 'includes/footer.php';
        ?>
    </body>
</html>
