<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
/*filter_input(INPUT_POST)
filter_input(INPUT_GET)

$_POST, $_GET, $_SESSION, $_SERVER, $_COOKIE, $_FILES*/
  if(isset($_POST['btnSubmit'])){
    include 'logic.php';
    $obj = new AppLogic();
    $obj->serverCon();

    $email = filter_input(INPUT_POST, "email");
    $pword = filter_input(INPUT_POST, "pword");
    //$email1 = $_POST['email'];
    //Declaring a query
    $query = "select Email, Password from userinfo where Email = '".$email."' and Password = '".$pword."' ";

    //Executing a query
    $results = mysqli_query($link, $query);

    $fetch = mysqli_fetch_array($results);

    $mail = $fetch['Email'];
    $p = $fetch['Password'];

    if($email == $mail && $pword == $p){
        header("location: admin/Admin_Page.php");
    }
    else{
        header("location: login.php");
    }
  }
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
       <?php
        // include the header here
        include 'includes/header.php';
        ?>
        <div id="main">
            <div id="formDiv">
                <form action="" method="POST">
                    <input type="email" name="email" placeholder="Email: examaple@gmail.com" required><br>
                    <input type="password" name="pword" placeholder="Password" required><br>
                    <input type="submit" name="btnSubmit" value="Login"><br>
                    
                </form>
            </div>
        </div>
        <?php
        // include the footer here
        include 'includes/footer.php';
        ?>
    </body>
</html>
